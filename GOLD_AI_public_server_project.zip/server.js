// GOLD AI public backend. Keep GEMINI_API_KEY in the hosting provider's environment variables.
const express = require("express");
const path = require("path");
const rateLimit = require("express-rate-limit");

const app = express();
app.set("trust proxy", 1);
app.use(express.json({ limit: "12mb" }));
app.use(express.static(path.join(__dirname, "public")));

const limiter = rateLimit({
  windowMs: 60 * 1000,
  limit: 5, // at most 5 analyses per IP per minute
  standardHeaders: "draft-7",
  legacyHeaders: false,
  message: { error: "وصلت للحد المؤقت للتحليلات. انتظر دقيقة وجرب مرة ثانية." }
});
app.use("/api/analyze", limiter);

app.get("/api/health", (_req, res) => {
  res.json({ ok: true, service: "GOLD AI" });
});

app.post("/api/analyze", async (req, res) => {
  try {
    const { imageBase64, mimeType, timeframe, style, risk, asset } = req.body || {};
    const apiKey = process.env.GEMINI_API_KEY;

    if (!apiKey) {
      return res.status(503).json({ error: "محرك التحليل غير مفعّل حالياً. يرجى المحاولة لاحقاً." });
    }
    if (typeof imageBase64 !== "string" ||
        !["image/png", "image/jpeg", "image/webp"].includes(mimeType)) {
      return res.status(400).json({ error: "الصورة مفقودة أو نوعها غير مدعوم. ارفع PNG أو JPG أو WEBP." });
    }
    if (imageBase64.length > 10_500_000) {
      return res.status(413).json({ error: "حجم الصورة كبير. اختَر صورة أصغر من 8MB." });
    }

    const prompt = `أنت مساعد تعليمي لتحليل صور الشارت، ولست مستشاراً مالياً.
الأداة: ${String(asset || "الذهب XAUUSD").slice(0, 40)}
الفريم: ${String(timeframe || "غير محدد").slice(0, 30)}
نوع التداول: ${String(style || "غير محدد").slice(0, 30)}
المخاطرة: ${String(risk || "غير محددة").slice(0, 30)}

حلل الصورة بالعربية العراقية الواضحة، وبالترتيب:
1) وضوح الصورة، والسعر الظاهر فقط إذا كان مقروءاً فعلاً.
2) الاتجاه العام والبنية السعرية والشموع والدعم والمقاومة الظاهرة.
3) السيناريو الأقرب: صعود أو هبوط أو انتظار، مع أسباب مختصرة.
4) إذا كانت هناك فرصة واضحة فقط، اذكر منطقة دخول محتملة ووقف خسارة وTP1 وTP2 وTP3 وسبب إبطال السيناريو. لا تخترع أي سعر؛ إذا الأرقام غير مقروءة أو الفرصة غير واضحة فاكتب انتظار.
5) نبّه إلى أن الصورة قديمة زمنياً وأن المستويات يجب مطابقتها مع السعر الحالي.

لا تدّعِ معرفة مؤشرات غير ظاهرة، ولا تخترع أسعاراً أو نسبة نجاح، ولا تضمن الربح. إذا كانت الصورة غير واضحة فقل ذلك صراحة.`;

    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 45000);
    let apiResponse;
    try {
      apiResponse = await fetch(
        "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.8-flash:generateContent?key=" + encodeURIComponent(apiKey),
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          signal: controller.signal,
          body: JSON.stringify({
            contents: [{
              parts: [
                { text: prompt },
                { inline_data: { mime_type: mimeType, data: imageBase64 } }
              ]
            }],
            generationConfig: { temperature: 0.2, maxOutputTokens: 1400 }
          })
        }
      );
    } finally {
      clearTimeout(timeout);
    }

    const data = await apiResponse.json().catch(() => ({}));
    if (!apiResponse.ok) {
      const googleMessage = data?.error?.message || "";
      if (apiResponse.status === 400 || apiResponse.status === 401 || apiResponse.status === 403) {
        return res.status(502).json({ error: "تعذر التحقق من إعدادات محرك التحليل. على مالك الموقع مراجعة مفتاح Gemini وصلاحياته." });
      }
      if (apiResponse.status === 429) {
        return res.status(429).json({ error: "طلبات التحليل كثيرة حالياً أو تم بلوغ حد الاستخدام. انتظر قليلاً ثم حاول مجدداً." });
      }
      if (apiResponse.status === 503 || apiResponse.status === 504) {
        return res.status(503).json({ error: "خدمة التحليل مزدحمة مؤقتاً. حاول بعد دقيقة." });
      }
      console.error("Gemini API error:", apiResponse.status, googleMessage);
      return res.status(502).json({ error: "حدثت مشكلة أثناء الاتصال بمحرك التحليل. حاول لاحقاً." });
    }

    const analysis = data?.candidates?.[0]?.content?.parts
      ?.map(part => part.text || "").join("\n").trim();

    if (!analysis) {
      return res.status(502).json({ error: "لم يرجع المحرك تحليلاً واضحاً. جرّب صورة أوضح." });
    }
    return res.json({ analysis });
  } catch (err) {
    if (err.name === "AbortError") {
      return res.status(504).json({ error: "استغرق التحليل وقتاً طويلاً. حاول مرة ثانية." });
    }
    console.error("GOLD AI server error:", err);
    return res.status(500).json({ error: "صار خطأ مؤقت بالخادم. حاول مرة ثانية." });
  }
});

const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`GOLD AI running on port ${port}`));
