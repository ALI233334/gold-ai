GOLD AI — نسخة عامة بمفتاح API مخفي

المهم:
- الزوار لا يدخلون أي مفتاح API.
- ضع GEMINI_API_KEY في إعدادات Environment Variables على منصة الاستضافة فقط.
- لا تضع المفتاح في index.html أو ترسله للزوار.
- تم وضع حد مبدئي: 5 طلبات تحليل لكل IP في الدقيقة. هذا لا يمنع كل أشكال الإساءة؛ راقب الاستهلاك وأضف تسجيل دخول/حصص يومية قبل إطلاق واسع.

التشغيل محلياً:
1) ثبّت Node.js 18 أو أحدث.
2) داخل مجلد المشروع شغّل: npm install
3) عيّن متغير البيئة GEMINI_API_KEY على جهاز الخادم.
   Linux/macOS: export GEMINI_API_KEY="YOUR_KEY"
   Windows PowerShell: $env:GEMINI_API_KEY="YOUR_KEY"
4) شغّل: npm start
5) افتح: http://localhost:3000

النشر:
- ارفع المجلد إلى خدمة استضافة Node.js مثل Render أو Railway أو خدمة تدعم Node.
- Build command: npm install
- Start command: npm start
- أضف Environment Variable باسم GEMINI_API_KEY وقيمته المفتاح الجديد.
- لا تضع المفتاح داخل ملفات الموقع أو GitHub.
- بعد النشر، افتح رابط الموقع. الزائر لا يحتاج مفتاحاً.

ملاحظات:
- يحتاج الخادم اتصال إنترنت وNode.js 18+ لدعم fetch.
- يستخدم المشروع Gemini API عبر generateContent ونموذج gemini-3.8-flash؛ تأكد من توفر النموذج لحسابك/منطقتك من Google AI Studio.
- تكاليف وحدود Gemini API على حساب مالك المفتاح. حد الطلبات الحالي لكل IP ليس ميزانية مالية ولا يغني عن مراقبة الاستهلاك.
- التحليل تعليمي وقد يخطئ، ولا يقدم ضمان ربح أو توصية استثمارية.
